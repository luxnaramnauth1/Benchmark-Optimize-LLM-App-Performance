#!/usr/bin/env python3
"""
make_report.py - Build the HOL1 deliverables from a REAL baseline run.

Usage:
    python make_report.py runs/YYYY-MM-DD_HHMMSS_baseline.csv
    (omit the argument to use the newest runs/*_baseline.csv)

Produces (next to the CSV, in runs/):
    <stem>_summary.csv   summary table (p50/p95, averages, outlier counts)
    HOL1_report.pdf      baseline report: summary table, outliers,
                         2 hypotheses (~200 words), executive summary

Every number and sentence is computed from the CSV you pass in -- nothing is
hard-coded -- so the report always matches your own run.
"""
import sys
from datetime import date
from pathlib import Path

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


def newest_baseline() -> Path:
    files = sorted(Path("runs").glob("*_baseline.csv"))
    if not files:
        sys.exit("No runs/*_baseline.csv found - run run_eval.py first.")
    return files[-1]


def load(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    ok = df[df["error"].isna()].copy() if "error" in df else df.copy()
    if ok.empty:
        sys.exit("All requests failed - fix the API setup and re-run the baseline.")
    return df, ok


def summarize(df: pd.DataFrame, ok: pd.DataFrame) -> dict:
    q = lambda s, p: float(s.quantile(p))
    s = {
        "p50_ttft": q(ok.ttft_ms, .5), "p95_ttft": q(ok.ttft_ms, .95),
        "p50_total": q(ok.total_ms, .5), "p95_total": q(ok.total_ms, .95),
        "avg_tps": float(ok.tokens_per_sec.mean()),
        "avg_cost": float(ok.cost_per_task.mean()),
        "total_cost": float(ok.cost_per_task.sum()),
        "avg_in": float(ok.input_tokens.mean()), "avg_out": float(ok.output_tokens.mean()),
        "n": len(df), "n_ok": len(ok),
    }
    s["ttft_ratio"] = s["p95_ttft"] / s["p50_ttft"] if s["p50_ttft"] else 0.0
    s["total_ratio"] = s["p95_total"] / s["p50_total"] if s["p50_total"] else 0.0
    # Outliers: total_ms above Tukey fence (Q3 + 1.5*IQR) and above p95; cost likewise
    def fence(col):
        q1, q3 = ok[col].quantile(.25), ok[col].quantile(.75)
        return q3 + 1.5 * (q3 - q1)
    s["lat_fence"], s["cost_fence"] = fence("total_ms"), fence("cost_per_task")
    s["lat_outliers"] = int((ok.total_ms > s["lat_fence"]).sum())
    s["cost_outliers"] = int((ok.cost_per_task > s["cost_fence"]).sum())
    s["above_p95"] = int((ok.total_ms > s["p95_total"]).sum())
    # Output length vs latency
    s["corr_out_total"] = float(ok.output_tokens.corr(ok.total_ms))
    med_out = ok.output_tokens.median()
    long_ = ok[ok.output_tokens > med_out]
    short = ok[ok.output_tokens <= med_out]
    s["med_out"] = float(med_out)
    s["long_total"] = float(long_.total_ms.mean()) if len(long_) else 0.0
    s["short_total"] = float(short.total_ms.mean()) if len(short) else 0.0
    s["ttft_share"] = float((ok.ttft_ms / ok.total_ms).median())
    s["out_share_cost"] = float(
        (ok.output_tokens * 0.0006).sum()
        / max((ok.input_tokens * 0.00015 + ok.output_tokens * 0.0006).sum(), 1e-12)
    )
    return s


def summary_table(s: dict) -> pd.DataFrame:
    rows = [
        ("p50 ttft_ms", f"{s['p50_ttft']:.1f}"), ("p95 ttft_ms", f"{s['p95_ttft']:.1f}"),
        ("p50 total_ms", f"{s['p50_total']:.1f}"), ("p95 total_ms", f"{s['p95_total']:.1f}"),
        ("p95/p50 ttft", f"{s['ttft_ratio']:.2f}x"), ("p95/p50 total", f"{s['total_ratio']:.2f}x"),
        ("avg tokens_per_sec", f"{s['avg_tps']:.1f}"),
        ("avg cost_per_task (USD)", f"{s['avg_cost']:.6f}"),
        ("total cost, all tasks (USD)", f"{s['total_cost']:.6f}"),
        ("avg input / output tokens", f"{s['avg_in']:.0f} / {s['avg_out']:.0f}"),
        ("latency outliers (Tukey fence)", f"{s['lat_outliers']} (> {s['lat_fence']:.0f} ms)"),
        ("cost outliers (Tukey fence)", f"{s['cost_outliers']}"),
        ("successful requests", f"{s['n_ok']}/{s['n']}"),
    ]
    return pd.DataFrame(rows, columns=["Metric", "Value"])


def hypotheses(s: dict, slow: pd.DataFrame) -> str:
    """Two metric-backed hypotheses, ~200 words, chosen from the actual data."""
    top = slow.iloc[0]
    h1 = (
        f"Hypothesis 1 - output length drives latency and cost. Output tokens correlate "
        f"with total_ms at r = {s['corr_out_total']:.2f}; responses longer than the median "
        f"({s['med_out']:.0f} tokens) average {s['long_total']:.0f} ms versus "
        f"{s['short_total']:.0f} ms for shorter ones, and the slowest request (prompt "
        f"{int(top.prompt_id)}, {top.total_ms:.0f} ms) produced {int(top.output_tokens)} tokens. "
        f"Output tokens are priced 4x input, so a tighter max_tokens or a 'be concise' "
        f"instruction should cut both total_ms and cost_per_task "
        f"(avg {s['avg_cost']:.6f} USD) with little loss for simple support questions. I would test this by re-running the "
        f"same 15 prompts with max_tokens halved and comparing p95 total_ms and cost."
    )
    h2 = (
        f"Hypothesis 2 - first-token wait is a separate cost worth attacking on its own. "
        f"p50 ttft_ms is {s['p50_ttft']:.0f} ms with p95/p50 = {s['ttft_ratio']:.2f}x, and TTFT is "
        f"a median {s['ttft_share']*100:.0f}% of total_ms. "
        + ("A ratio above 3x points to network or cold-start jitter, so regional endpoints and "
           "connection reuse are the first things to try."
           if s["ttft_ratio"] > 3 else
           "The ratio is below 3x, so jitter is modest; gains must come from shortening "
           "the prompt/prefill, caching the shared system prompt, or routing simple FAQ-style "
           "prompts to a smaller model. Success means a lower p50 ttft_ms without raising p95.")
    )
    return h1 + "\n\n" + h2


def exec_summary(s: dict) -> str:
    lat = (f"Latency is {'tightly' if s['total_ratio'] < 2 else 'unevenly'} distributed "
           f"(total p50 {s['p50_total']:.0f} ms, p95 {s['p95_total']:.0f} ms, ratio "
           f"{s['total_ratio']:.2f}x; TTFT p50 {s['p50_ttft']:.0f} ms).")
    thr = (f"Throughput averaged {s['avg_tps']:.1f} tokens/sec and cost averaged "
           f"${s['avg_cost']:.6f} per task (${s['total_cost']:.5f} for {s['n_ok']} prompts).")
    flagged = s['lat_outliers'] + s['cost_outliers']
    out = (f"{s['lat_outliers']} latency and {s['cost_outliers']} cost outlier(s) were flagged"
           + (", and the slowest requests track long outputs rather than a systemic bottleneck."
              if flagged and s['corr_out_total'] > .5 else
              "; the slowest requests (listed above) are the tail to watch, not a clear bottleneck."
              if not flagged else "."))
    ready = ("All requests succeeded, so the baseline is a usable reference for optimization experiments."
             if s["n_ok"] == s["n"] else
             f"{s['n'] - s['n_ok']} request(s) failed; resolve these before comparing variants.")
    return " ".join([lat, thr, out, ready])


def build_pdf(path: Path, csv_name: str, df, ok, s, tbl, slow, costly, hyp, summ):
    st = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=st["BodyText"], fontSize=10, leading=14)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10)
    doc = SimpleDocTemplate(str(path), pagesize=letter, leftMargin=.8*inch, rightMargin=.8*inch,
                            topMargin=.7*inch, bottomMargin=.7*inch, title="HOL1 Baseline Report")
    E = [Paragraph("HOL1: Baseline or Bust - Baseline Report", st["Title"]),
         Paragraph(f"Source run: {csv_name} | model: {df.model.iloc[0]} | "
                   f"variant: {df.variant.iloc[0]} | generated {date.today()}", small),
         Spacer(1, 10), Paragraph("Executive Summary", st["Heading2"]),
         Paragraph(summ, body), Spacer(1, 8), Paragraph("Summary Table", st["Heading2"])]

    def grid(data, widths=None, hdr=True):
        t = Table(data, colWidths=widths, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0056D2")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("GRID", (0, 0), (-1, -1), .4, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5FA")]),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
        return t

    E.append(grid([list(tbl.columns)] + tbl.values.tolist(), [3.2*inch, 3.0*inch]))
    E += [Spacer(1, 10), Paragraph("Outliers: slowest requests (by total_ms)", st["Heading2"])]
    E.append(grid([["prompt_id", "prompt", "total_ms", "out_tok", "cost"]] +
                  [[int(r.prompt_id), Paragraph(r.prompt, small), f"{r.total_ms:.0f}",
                    int(r.output_tokens), f"{r.cost_per_task:.6f}"] for r in slow.itertuples()],
                  [.7*inch, 3.2*inch, .8*inch, .7*inch, .9*inch]))
    E += [Spacer(1, 8), Paragraph("Outliers: highest cost", st["Heading3"])]
    E.append(grid([["prompt_id", "prompt", "cost", "out_tok"]] +
                  [[int(r.prompt_id), Paragraph(r.prompt, small), f"{r.cost_per_task:.6f}",
                    int(r.output_tokens)] for r in costly.itertuples()],
                  [.7*inch, 3.8*inch, .9*inch, .9*inch]))
    E += [Spacer(1, 10), Paragraph("Reflection: Two Hypotheses", st["Heading2"])]
    for para in hyp.split("\n\n"):
        E += [Paragraph(para, body), Spacer(1, 6)]
    E += [Paragraph("Per-prompt Baseline (all test cases)", st["Heading2"])]
    cols = ["prompt_id", "ttft_ms", "total_ms", "input_tokens", "output_tokens",
            "tokens_per_sec", "cost_per_task"]
    E.append(grid([cols] + [[f"{v:.6g}" if isinstance(v, float) else v for v in row]
                            for row in df[cols].fillna("ERR").values.tolist()]))
    doc.build(E)


def main():
    csv_path = Path(sys.argv[1]) if len(sys.argv) > 1 else newest_baseline()
    df, ok = load(csv_path)
    s = summarize(df, ok)
    tbl = summary_table(s)
    slow = ok.nlargest(3, "total_ms")
    costly = ok.nlargest(3, "cost_per_task")
    hyp, summ = hypotheses(s, slow), exec_summary(s)

    out_dir = csv_path.parent
    tbl.to_csv(out_dir / f"{csv_path.stem}_summary.csv", index=False)
    build_pdf(out_dir / "HOL1_report.pdf", csv_path.name, df, ok, s, tbl, slow, costly, hyp, summ)

    print(tbl.to_string(index=False))
    print("\nEXECUTIVE SUMMARY\n" + summ)
    print(f"\nREFLECTION ({len(hyp.split())} words)\n" + hyp)
    print(f"\nWrote {out_dir / (csv_path.stem + '_summary.csv')} and {out_dir / 'HOL1_report.pdf'}")


if __name__ == "__main__":
    main()
