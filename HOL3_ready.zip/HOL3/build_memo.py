#!/usr/bin/env python3
"""
build_memo.py - Build HOL3_report.pdf (metrics table + chart + Ship/No-Ship memo)
from a REAL run of run_experiments.py.

Usage:  python build_memo.py [results_dir]      (default: results)
Needs:  results/variant_A.csv, variant_B.csv, variant_C.csv, summary_metrics.csv
Writes: results/decision_chart.png, results/HOL3_report.pdf

The recommendation follows explicit rules (below) applied to your numbers, and every
figure in the memo is read from the CSVs. Read it, then edit wording as you see fit.
Rules: a variant is ELIGIBLE if error_rate <= 5%, p95/p50 < 2, p95 <= 1.5x A's p95,
cost <= 1.5x A's, and (win_rate_vs_A > 50 OR (p95 >= 20% faster AND quality >= 90% of A)).
Ship the eligible variant with the best win-rate (ties: lower p95); none eligible = No-Ship (keep A).
"""
import sys
from datetime import date
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

def load(d):
    s = pd.read_csv(d / "summary_metrics.csv").set_index("variant")
    if not {"A", "B", "C"} <= set(s.index):
        sys.exit("summary_metrics.csv must contain variants A, B and C - run all three.")
    return s

def evaluate(s):
    A, rows = s.loc["A"], {}
    for v in ("B", "C"):
        r = s.loc[v]
        win = float(r.win_rate_vs_A)
        faster = r.p95_latency_ms <= 0.8 * A.p95_latency_ms
        checks = {
            "error rate <= 5%": r.error_rate <= 5,
            "p95/p50 < 2": r.p95_latency_ms / r.p50_latency_ms < 2,
            "p95 <= 1.5x A": r.p95_latency_ms <= 1.5 * A.p95_latency_ms,
            "cost <= 1.5x A": r.avg_cost_per_task <= 1.5 * A.avg_cost_per_task,
            "quality case": win > 50 or (faster and r.avg_quality_score >= 0.9 * A.avg_quality_score),
        }
        rows[v] = (all(checks.values()), checks, win)
    elig = {v: x for v, x in rows.items() if x[0]}
    if not elig:
        return "A", rows
    return sorted(elig, key=lambda v: (-elig[v][2], s.loc[v].p95_latency_ms))[0], rows

def chart(s, d):
    fig, ax = plt.subplots(1, 4, figsize=(13, 3.4))
    spec = [("p95_latency_ms", "p95 latency (ms)"), ("avg_cost_per_task", "Avg cost / task (USD)"),
            ("avg_quality_score", "Avg quality score (0-100)"), ("win_rate_vs_A", "Win-rate vs A (%)")]
    for a, (c, t) in zip(ax, spec):
        a.bar(["A", "B", "C"], [s.loc[v][c] for v in "ABC"], color=["#6b7280", "#0056D2", "#16a34a"])
        a.set_title(t, fontsize=10)
        for i, v in enumerate("ABC"):
            a.text(i, s.loc[v][c], f"{s.loc[v][c]:.4g}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout(); p = d / "decision_chart.png"; fig.savefig(p, dpi=150); plt.close(fig); return p

def main():
    d = Path(sys.argv[1] if len(sys.argv) > 1 else "results")
    s = load(d); pick, ev = evaluate(s); A = s.loc["A"]; P = s.loc[pick]
    mock = "MOCK" in str(s.variant_name.iloc[0]).upper() or (d / "MOCK_DATA").exists()
    png = chart(s, d)
    ratio = lambda v: s.loc[v].p95_latency_ms / s.loc[v].p50_latency_ms
    pct = lambda a, b: (a - b) / b * 100
    ship = pick != "A"
    rec = f"SHIP Variant {pick} ({P.variant_name})" if ship else "NO-SHIP: keep Variant A (Baseline)"
    why = []
    if ship:
        why.append(f"Variant {pick} has p95 latency {P.p95_latency_ms:.0f} ms vs {A.p95_latency_ms:.0f} ms for A "
                   f"({pct(P.p95_latency_ms, A.p95_latency_ms):+.0f}%), cost per task ${P.avg_cost_per_task:.6f} vs "
                   f"${A.avg_cost_per_task:.6f} ({pct(P.avg_cost_per_task, A.avg_cost_per_task):+.0f}%), quality score "
                   f"{P.avg_quality_score:.1f} vs {A.avg_quality_score:.1f}, and a {ev[pick][2]:.0f}% win-rate against A.")
    else:
        why.append("Neither B nor C met every ship criterion against baseline A: " + "; ".join(
            f"{v} failed [{', '.join(k for k, ok in ev[v][1].items() if not ok)}]" for v in "BC") + ".")
    why.append(f"Consistency (p95/p50): A {ratio('A'):.2f}x, B {ratio('B'):.2f}x, C {ratio('C'):.2f}x. "
               f"Fastest p95: {s.p95_latency_ms.idxmin()}; cheapest: {s.avg_cost_per_task.idxmin()}; "
               f"highest quality: {s.avg_quality_score.idxmax()}.")
    why.append(f"Speed vs quality: B cuts p95 by {-pct(s.loc['B'].p95_latency_ms, A.p95_latency_ms):.0f}% but its quality score is "
               f"{s.loc['B'].avg_quality_score - A.avg_quality_score:+.1f} points vs A; C scores "
               f"{s.loc['C'].avg_quality_score - A.avg_quality_score:+.1f} points but its p95 is {pct(s.loc['C'].p95_latency_ms, A.p95_latency_ms):+.0f}% vs A.")
    why.append(f"Cost vs quality: per-task cost is {pct(s.loc['B'].avg_cost_per_task, A.avg_cost_per_task):+.0f}% for B and "
               f"{pct(s.loc['C'].avg_cost_per_task, A.avg_cost_per_task):+.0f}% for C relative to A, so any quality gain from C is bought with higher spend and longer tails.")
    why.append("Quality here is a heuristic (length, structure, keywords), not human or LLM-judge evaluation, so "
               "win-rate favours longer answers and should be treated as directional.")
    base = P if ship else A
    roll = (f"Within the first 24 hours, roll back to Variant A if p95 latency exceeds {2*A.p95_latency_ms:.0f} ms "
            f"(2x baseline), error rate exceeds 2%, or cost per task exceeds ${1.5*base.avg_cost_per_task:.6f} "
            f"(1.5x the measured value).")
    nxt = ("Replace the heuristic with an LLM-as-judge or human review on a sample, add repeat runs to estimate "
           "variance, and test a hybrid that routes simple prompts to the cheaper variant.")

    st = getSampleStyleSheet(); body = ParagraphStyle("b", parent=st["BodyText"], fontSize=10, leading=14)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10)
    E = [Paragraph("HOL3: Experiment Orchestrator - Ship/No-Ship Decision Memo", st["Title"]),
         Paragraph(f"Date: {date.today()} | Model: gpt-4o-mini | Cases per variant: {int(A.total_cases)}", small)]
    if mock:
        E.append(Paragraph("<font color='red'><b>SAMPLE LAYOUT - SYNTHETIC MOCK DATA, NOT A REAL EXPERIMENT. Do not submit.</b></font>", body))
    E += [Spacer(1, 6), Paragraph("Recommendation", st["Heading2"]), Paragraph(f"<b>{rec}</b>", body),
          Paragraph("Metrics", st["Heading2"])]
    hdr = ["Metric", "A Baseline", "B Fast", "C High-Quality"]
    m = [("p50 latency (ms)", "p50_latency_ms", "{:.0f}"), ("p95 latency (ms)", "p95_latency_ms", "{:.0f}"),
         ("Avg tokens/sec", "avg_tokens_per_sec", "{:.1f}"), ("Avg cost/task (USD)", "avg_cost_per_task", "{:.6f}"),
         ("Avg quality (0-100)", "avg_quality_score", "{:.1f}"), ("Win-rate vs A (%)", "win_rate_vs_A", "{:.0f}"),
         ("Error rate (%)", "error_rate", "{:.1f}")]
    data = [hdr] + [[n] + [f.format(s.loc[v][c]) for v in "ABC"] for n, c, f in m]
    t = Table(data, colWidths=[2.2*inch, 1.4*inch, 1.4*inch, 1.6*inch])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0056D2")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("GRID", (0, 0), (-1, -1), .4, colors.grey)]))
    E += [t, Spacer(1, 8), Image(str(png), width=6.9*inch, height=6.9*inch*3.4/13),
          Paragraph("Justification and trade-offs", st["Heading2"])] + [Paragraph(x, body) for x in why] + [
          Paragraph("Rollback trigger", st["Heading2"]), Paragraph(roll, body),
          Paragraph("Next step", st["Heading2"]), Paragraph(nxt, body)]
    out = d / "HOL3_report.pdf"
    SimpleDocTemplate(str(out), pagesize=letter, leftMargin=.8*inch, rightMargin=.8*inch,
                      topMargin=.7*inch, bottomMargin=.7*inch, title="HOL3 Decision Memo").build(E)
    words = sum(len(x.split()) for x in why + [roll, nxt])
    print(rec); print(f"memo words ~{words}; wrote {out}")

if __name__ == "__main__":
    main()
