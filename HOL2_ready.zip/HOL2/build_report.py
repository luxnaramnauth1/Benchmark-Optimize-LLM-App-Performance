#!/usr/bin/env python3
"""build_report.py - builds HOL2_report.pdf from logs/sim_summary.json (run simulate_failures.py first)."""
import json
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

RETRY = (
"The middleware retries up to three times, so a request makes at most four attempts. One retry fixes most "
"momentary 429s and timeouts, while three covers a short outage without a wait beyond about seven seconds."
" Delays double on each retry (1s, 2s, 4s, capped at 16s) so the provider gets progressively "
"more time to recover. Random jitter of plus or minus 200 ms is added so that many clients who failed "
"together do not all retry at the same instant (the thundering herd). Retries stop after the third retry, "
"on the first success, or immediately for errors that will never succeed: 400, 401, 403, 404 and 422 fail "
"fast with no sleep. Only 429, 5xx, timeouts and connection errors are retried. Bounded attempts and jitter keep our traffic from piling onto an already overloaded API, which is what prevents a "
"local blip from cascading into a wider outage.")

REFLECT = (
"Retries help when failures are transient: in the simulation a single 429 cost about one extra second but "
"turned an error into an answer. They hurt when the failure is persistent, because an exhausted request "
"burned about seven seconds of backoff and still failed, and retried traffic adds load to a provider that is "
"already throttling us. Non-retryable errors such as 401 should fail fast, and the simulation returned one in "
"under a millisecond. Caching changes the dynamics for deterministic, repeated prompts: the repeated prompt was "
"served in effectively zero time with zero cost and no API call, though it is only safe at temperature 0 and "
"can return stale answers. p95 matters more than p50 because retries create a long tail: the median request "
"may be fast while one in twenty waits through several backoffs, and users judge a service by its worst "
"experiences, while timeouts and capacity are sized to the tail. Middleware design therefore decides real "
"user experience: bounded retries, jitter, caching and per-request logs of retry_count and latency trade a "
"little median latency for far fewer visible failures, and make that trade measurable.")

def wc(s): return len(s.split())

def main():
    rows = json.load(open("logs/sim_summary.json"))
    assert 100 <= wc(RETRY) <= 150, wc(RETRY)
    st = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=st["BodyText"], fontSize=10, leading=14)
    small = ParagraphStyle("s", parent=body, fontSize=8, leading=10)
    doc = SimpleDocTemplate("HOL2_report.pdf", pagesize=letter, leftMargin=.8*inch, rightMargin=.8*inch,
                            topMargin=.7*inch, bottomMargin=.7*inch, title="HOL2 Backend Reliability Report")
    E = [Paragraph("HOL2: Backend Reliability Challenge - Handle It Smart", st["Title"]),
         Paragraph("Deliverables: middleware script, retry policy explanation, performance reflection", small),
         Spacer(1, 8), Paragraph("1. Middleware Script", st["Heading2"]),
         Paragraph("<b>middleware.py</b> (class <font face='Courier'>LLMMiddleware</font>) wraps "
                   "chat.completions with: <b>retry/backoff</b> (max 3 retries, delay = min(1s x 2^attempt, 16s) "
                   "&plusmn; 200 ms jitter), <b>timeout handling</b> (30 s client timeout, APITimeoutError is "
                   "retried), <b>caching</b> (in-memory, MD5 prompt hash, hit returns instantly with "
                   "cache_hit=true) and <b>structured JSONL logging</b> to logs/run_*.jsonl (timestamp, "
                   "prompt_hash, latency_ms, retry_count, input/output tokens, cost_estimate, cache_hit, "
                   "success, error). Retryable: 429, 5xx, timeouts, connection errors. Fail fast: 4xx.", body),
         Spacer(1, 6),
         Paragraph("<b>Evidence (simulated provider).</b> <font size=8>The real middleware was run against a fake "
                   "client that injects failures, because no live API key was available when this report was "
                   "generated. Backoff waits and logged retry_count are genuinely measured; the 150 ms model time "
                   "and token counts are synthetic. Re-run <font face='Courier'>python middleware.py</font> with a "
                   "key for live numbers.</font>", body), Spacer(1, 4)]
    data = [["Scenario", "API calls", "Retries", "Latency (ms)", "Result", "Cache"]]
    for r in rows:
        res = "success" if r["success"] else f"fail: {r['error']}"
        data.append([Paragraph(r["scenario"], small), r["api_calls"], r["retry_count"],
                     f"{r['latency_ms']:.1f}", Paragraph(res, small), "hit" if r["cache_hit"] else "-"])
    t = Table(data, colWidths=[2.2*inch, .7*inch, .6*inch, .9*inch, 1.6*inch, .5*inch], repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0056D2")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), .4, colors.grey), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F2F5FA")])]))
    E += [t, Spacer(1, 10), Paragraph(f"2. Retry Policy Explanation ({wc(RETRY)} words)", st["Heading2"]),
          Paragraph(RETRY, body), Spacer(1, 8),
          Paragraph(f"3. Performance Reflection ({wc(REFLECT)} words)", st["Heading2"]), Paragraph(REFLECT, body)]
    doc.build(E)
    print("retry words:", wc(RETRY), "| reflection words:", wc(REFLECT))

if __name__ == "__main__":
    main()
