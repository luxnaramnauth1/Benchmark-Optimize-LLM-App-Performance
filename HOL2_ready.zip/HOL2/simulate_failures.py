#!/usr/bin/env python3
"""
simulate_failures.py - Activity 2 evidence without a live API key.

Runs the REAL LLMMiddleware (retry, backoff, jitter, cache, logging) against a
fake OpenAI client that injects failures. No network is used. Latency of the
backoff sleeps is genuinely measured; token counts and the fake model latency
are synthetic. Re-run your own live demo with `python middleware.py` for real
API numbers.

Usage: python simulate_failures.py   -> logs/sim_*.jsonl and logs/sim_summary.json
"""
import json, os, time, types
from pathlib import Path

import httpx
os.environ.setdefault("OPENAI_API_KEY", "sk-simulated-not-a-real-key")
from openai import RateLimitError, APITimeoutError, AuthenticationError, InternalServerError
from middleware import LLMMiddleware

REQ = httpx.Request("POST", "https://api.openai.com/v1/chat/completions")

def err(kind):
    if kind == "429":
        return RateLimitError("Rate limit exceeded", response=httpx.Response(429, request=REQ), body=None)
    if kind == "500":
        return InternalServerError("Server error", response=httpx.Response(500, request=REQ), body=None)
    if kind == "401":
        return AuthenticationError("Invalid API key", response=httpx.Response(401, request=REQ), body=None)
    if kind == "timeout":
        return APITimeoutError(request=REQ)

class FakeClient:
    """Raises the scripted errors in order, then returns a canned completion."""
    def __init__(self, script):
        self.script, self.calls = list(script), 0
        self.chat = types.SimpleNamespace(completions=types.SimpleNamespace(create=self._create))
    def _create(self, **kw):
        self.calls += 1
        if self.script:
            k = self.script.pop(0)
            if k:
                raise err(k)
        time.sleep(0.15)  # synthetic model time
        msg = types.SimpleNamespace(content="Simulated answer.")
        return types.SimpleNamespace(
            choices=[types.SimpleNamespace(message=msg, finish_reason="stop")],
            usage=types.SimpleNamespace(prompt_tokens=28, completion_tokens=12), model="gpt-4o-mini")

SCENARIOS = [  # name, prompt, error script
    ("S1 clean call", "What is 1 + 1?", []),
    ("S2 one 429 then success", "What is 2 + 2?", ["429"]),
    ("S3 timeout then success", "What is 3 + 3?", ["timeout"]),
    ("S4 three 500s then success", "What is 4 + 4?", ["500", "500", "500"]),
    ("S5 429 forever (exhausted)", "What is 5 + 5?", ["429"] * 10),
    ("S6 401 (fail fast)", "What is 6 + 6?", ["401"]),
    ("S7 repeat of S1 (cache hit)", "What is 1 + 1?", []),
]

def main():
    Path("logs").mkdir(exist_ok=True)
    mw = LLMMiddleware()
    mw.log_file = Path("logs") / "sim_run.jsonl"
    mw.log_file.write_text("")
    rows = []
    for name, prompt, script in SCENARIOS:
        mw.client = FakeClient(script)
        print(f"\n--- {name}")
        t = time.perf_counter(); res = mw.call(prompt); wall = (time.perf_counter() - t) * 1000
        last = json.loads(mw.log_file.read_text().strip().splitlines()[-1])
        rows.append(dict(scenario=name, api_calls=mw.client.calls, retry_count=last["retry_count"],
                         latency_ms=last["latency_ms"], success=last["success"],
                         cache_hit=last["cache_hit"], cost_estimate=last["cost_estimate"],
                         error=(last["error"] or "")[:60]))
    Path("logs/sim_summary.json").write_text(json.dumps(rows, indent=2))
    print("\nWrote logs/sim_run.jsonl and logs/sim_summary.json")

if __name__ == "__main__":
    main()
